Categories: Fantasy & Nature 

Galadriel's Mirror ICQ skin 
===========================
http://galadrielsmirror.cjb.net/skin.html

version 1.2
created 2000-Apr-03, last updated 2000-Apr-22
Licq version 1
created 2000-Apr-21, last updated 2000-Apr-23

A skin to fit the look of Galadriel's Mirror (http://galadrielsmirror.cjb.net), a shell site to the Lord of the Rings & Tolkien Things messageboard (http://tolkienthings.cjb.net) at www.gamers.com 

I've tried to make a skin which looks like the kind of nightsky reflected in Galadriel's Mirror ... 

Best viewed with the Galadriels_Mirror icon pack and the TrueType Tolkien Regular Font (TOLKY.TTF) (FreeType converted font looks nicest with size 16). 

made by Ioreth
(alatariels_mirror@hotmail.com)

