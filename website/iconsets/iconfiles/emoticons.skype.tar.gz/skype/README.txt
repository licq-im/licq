these emoticons are based on 
skype smiley collection 1.0.0.0
(http://www.miranda-im.org/download/details.php?action=viewfile&id=1627)

edited by jose <zefo at seznam dot cz>